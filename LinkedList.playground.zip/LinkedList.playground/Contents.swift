import UIKit

/// Represents every item in a `LinkedList`.
class Node {
    var value: String
    var next: Node?
    weak var previous: Node?
    
    init(value: String) {
        self.value = value
    }
}

class LinkedList {
    private var head: Node?
    private var tail: Node?
    
    func isEmpty() -> Bool {
        self.head == nil
    }
    
    func getFirstNode() -> Node? {
        self.head
    }
    
    func getLastNode() -> Node? {
        self.tail
    }
    
    func push(value: String) {
        // Create a new item
        let newNode = Node(value: value)
        
        // If we have a tail node
        // then it means there's something in the linkedList already.
        // And if so, let's configure the `newNode` item to point to the tail
        // of the list as it's previous item.
        // Similarly, configure the `newNode` item on the list to point to the `newNode` as its next item.
        
        if let tailNode = tail {
            newNode.previous = tailNode
            tailNode.next = newNode
        } else {
            self.head = newNode
        }
        
        // Finally, set the tail of the list to be the new item.
        // Remember that every new item goes to the tail of the linkedList.
        self.tail = newNode
    }
    
    func getNodeAtIndex(_ index: Int) -> Node? {
        if index >= 0 {
            // Mutable index variable.
            var i = index
            // We start at node located in our head.
            var currentNode = self.head
            
            while currentNode != nil {
                if i == 0 {
                    return currentNode
                } else {
                    i -= 1
                    currentNode = currentNode?.next
                }
            }
            
            return currentNode
            
        } else {
            return nil
        }
    }
}

extension LinkedList: CustomStringConvertible {
    var description: String {
        var text = "["
        var node = self.head
        
        while node != nil {
            text += "\(node!.value)"
            let nextNode = node!.next
            node = nextNode
            
            if nextNode != nil {
                text += ", "
            }
        }
        
        return text + "]"
    }
}

let list = LinkedList()
list.push(value: "Glenn")
list.push(value: "Diana")
list.push(value: "Adam")
list.push(value: "Claire Ayne")
list.push(value: "Mommy")
list.push(value: "Daddy")

print(list.description)

let index = 100
print("The node located at index \(index) is: \(list.getNodeAtIndex(index)?.value ?? "none!")")
